import tkinter as tk
from tkinter import ttk
import serial
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
from matplotlib.animation import FuncAnimation

class InterfazArduino:
    def __init__(self, puerto, baudrate=9600):
        # Inicializar la interfaz de usuario y la conexión serial
        self.wind_Ard = tk.Tk()
        self.wind_Ard.title("Control de Intensidad LED RGB")

        self.intensidad_rojo = tk.StringVar()
        self.intensidad_azul = tk.StringVar()
        self.intensidad_verde = tk.StringVar()

        try:
            self.ser = serial.Serial(puerto, baudrate, timeout=1)
        except serial.SerialException as e:
            print(f"Error al establecer la conexión serial: {e}")
            self.ser = None

        if self.ser:
            # Crear los widgets de la interfaz
            self.crear_widgets()
            # Actualizar las intensidades y configurar la animación
            self.actualizar_intensidades()
            self.configurar_animacion()
        else:
            print("La conexión serial no se pudo establecer. Saliendo.")
            self.wind_Ard.destroy()

    def crear_widgets(self):
        # Crear etiquetas y controles deslizantes para las intensidades
        ttk.Label(self.wind_Ard, text="Intensidad Rojo:").grid(row=0, column=0, padx=10, pady=10, sticky='w')
        self.slider_rojo = ttk.Scale(self.wind_Ard, from_=0, to=255, orient="horizontal", variable=self.intensidad_rojo)
        self.slider_rojo.grid(row=0, column=1, padx=10, pady=10)

        ttk.Label(self.wind_Ard, text="Intensidad Azul:").grid(row=1, column=0, padx=10, pady=10, sticky='w')
        self.slider_azul = ttk.Scale(self.wind_Ard, from_=0, to=255, orient="horizontal", variable=self.intensidad_azul)
        self.slider_azul.grid(row=1, column=1, padx=10, pady=10)

        ttk.Label(self.wind_Ard, text="Intensidad Verde:").grid(row=2, column=0, padx=10, pady=10, sticky='w')
        self.slider_verde = ttk.Scale(self.wind_Ard, from_=0, to=255, orient="horizontal", variable=self.intensidad_verde)
        self.slider_verde.grid(row=2, column=1, padx=10, pady=10)

        # Crear un gráfico para visualizar las intensidades
        self.fig, self.ax = plt.subplots()
        self.ax.set_ylim(0, 255)
        self.ax.set_xlabel("Tiempo")
        self.ax.set_ylabel("Intensidad")
        self.linea_rojo, = self.ax.plot([], [], label="Rojo")
        self.linea_azul, = self.ax.plot([], [], label="Azul")
        self.linea_verde, = self.ax.plot([], [], label="Verde")
        self.ax.legend()

        # Crear un lienzo para mostrar el gráfico en la interfaz
        self.canvas = FigureCanvasTkAgg(self.fig, master=self.wind_Ard)
        self.widget_canvas = self.canvas.get_tk_widget()
        self.widget_canvas.grid(row=3, columnspan=2, padx=10, pady=10)

    def actualizar_intensidades(self):
        # Actualizar las intensidades desde los datos leídos por la comunicación serial
        if self.ser:
            try: 
                datos = self.ser.readline().decode('utf-8').strip().split(',')
                if len(datos) == 3 and all(d.isdigit() or not d for d in datos):
                    self.intensidad_rojo.set(datos[0])
                    self.intensidad_azul.set(datos[1])
                    self.intensidad_verde.set(datos[2])
            except (serial.SerialException, ValueError) as e:
                print(f"Error de comunicación serial: {e}")

            # Programar la función para ejecutarse periódicamente
            self.wind_Ard.after(100, self.actualizar_intensidades)

    def actualizar_grafico(self, cuadro):
        # Actualizar el gráfico con las intensidades actuales
        if self.ser:
            try:
                intensidad_rojo = int(float(self.intensidad_rojo.get())) if self.intensidad_rojo.get() else 0
                intensidad_azul = int(float(self.intensidad_azul.get())) if self.intensidad_azul.get() else 0
                intensidad_verde = int(float(self.intensidad_verde.get())) if self.intensidad_verde.get() else 0
            except (ValueError, tk.TclError) as e:
                print(f"Error al convertir intensidades a entero: {e}")
                intensidad_rojo, intensidad_azul, intensidad_verde = 0, 0, 0

            # Configurar los datos para el gráfico
            datos_x = range(cuadro - 50, cuadro + 1)
            datos_y_rojo = [intensidad_rojo] * len(datos_x)
            datos_y_azul = [intensidad_azul] * len(datos_x)
            datos_y_verde = [intensidad_verde] * len(datos_x)

            # Actualizar las líneas del gráfico
            self.linea_rojo.set_data(datos_x, datos_y_rojo)
            self.linea_azul.set_data(datos_x, datos_y_azul)
            self.linea_verde.set_data(datos_x, datos_y_verde)

            # Configurar los límites del eje x
            self.ax.set_xlim(max(0, cuadro - 50), cuadro + 1)

    def configurar_animacion(self):
        # Configurar la animación para actualizar el gráfico periódicamente
        if self.ser:
            num_cuadros = 100
            self.animacion = FuncAnimation(self.fig, self.actualizar_grafico, frames=num_cuadros, interval=100, cache_frame_data=False)

    def al_cerrar(self):
        # Cerrar la conexión serial al cerrar la interfaz
        if self.ser:
            self.ser.close()
        self.wind_Ard.destroy()

    def ejecutar(self):
        # Configurar la acción al cerrar y ejecutar la interfaz
        self.wind_Ard.protocol("WM_DELETE_WINDOW", self.al_cerrar)
        self.wind_Ard.mainloop()

# Ejecutar la interfaz si este script es el principal
if __name__ == "__main__":
    interfaz_arduino = InterfazArduino(puerto='COM3')
    interfaz_arduino.ejecutar()
